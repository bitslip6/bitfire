import Link from 'next/link';
import React, { useState } from 'react';
import Collapse from 'react-css-collapse';

export default function Sidenav(props) {
  const [open, setOpen] = useState(false);
  const [openCategory, setOpenCategory] = useState('');
  const [openSubcategory, setOpenSubcategory] = useState('');
  const [openDropdown, setOpenDropdown] = useState(false);

  function handleCategoryClick(e, category) {
    e.preventDefault();
    setOpenSubcategory('');
    setOpenCategory(category === openCategory ? '' : category);
  }

  function handleSubcategoryClick(e, subcategory) {
    e.preventDefault();
    setOpenSubcategory(subcategory === openSubcategory ? '' : subcategory);
  }

  function handleDropdownClick(e, state) {
    e.preventDefault();
    setOpenDropdown(state);
  }

  return (
    <nav
      className="navbar navbar-vertical fixed-start navbar-expand-md navbar-light"
      id="sidebar"
      {...props}
    >
      <div className="container-fluid">
        {/* Navbar toggler */}
        <button
          className="navbar-toggler"
          type="button"
          aria-controls="sidebarCollapse"
          aria-expanded={!!open}
          aria-label="Toggle navigation"
          onClick={() => setOpen(!open)}
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        {/* Navbar brand */}
        <Link href="/">
          <a className="navbar-brand">
            <img
              src="/img/logo.svg"
              className="navbar-brand-img mx-auto"
              alt="..."
            />
          </a>
        </Link>

        {/* Navbar user (mobile) */}
        <div className="navbar-user d-md-none">
          <div className="dropdown">
            <a
              href="#"
              id="sidebarIcon"
              className="dropdown-toggle"
              role="button"
              aria-haspopup="true"
              aria-expanded={!!openDropdown}
              onClick={(e) => handleDropdownClick(e, !openDropdown)}
            >
              <div className="avatar avatar-sm avatar-online">
                <img
                  src="/img/avatars/profiles/avatar-1.jpg"
                  className="avatar-img rounded-circle"
                  alt="..."
                />
              </div>
            </a>
            {openDropdown && (
              <div
                className="dropdown-menu dropdown-menu-end show"
                aria-labelledby="sidebarIcon"
              >
                <a href="#" className="dropdown-item">
                  Profile
                </a>
                <a href="#" className="dropdown-item">
                  Settings
                </a>
                <hr className="dropdown-divider" />
                <a href="#" className="dropdown-item">
                  Logout
                </a>
              </div>
            )}
          </div>
        </div>

        {/* Navbar collapse */}
        <Collapse
          className="navbar-collapse"
          id="sidebarCollapse"
          isOpen={open}
        >
          {/* Navbar search */}
          <form className="mt-4 mb-3 d-md-none">
            <div className="input-group input-group-rounded input-group-merge input-group-reverse">
              <input
                className="form-control"
                type="search"
                placeholder="Search"
                aria-label="Search"
              />
              <div className="input-group-text">
                <span className="fe fe-search"></span>
              </div>
            </div>
          </form>

          {/* Navbar nav */}
          <ul className="navbar-nav">
            <li className="nav-item">
              <a
                className="nav-link"
                href="#"
                role="button"
                aria-expanded={openCategory === 'dashboards'}
                aria-controls="sidebarDashboards"
                onClick={(e) => handleCategoryClick(e, 'dashboards')}
              >
                <i className="fe fe-home"></i> Dashboards
              </a>
              <Collapse
                id="sidebarDashboards"
                isOpen={openCategory === 'dashboards'}
              >
                <ul className="nav nav-sm flex-column">
                  <li className="nav-item">
                    <Link href="/">
                      <a className="nav-link">Default</a>
                    </Link>
                  </li>
                  <li className="nav-item">
                    <a href="#" className="nav-link">
                      Project Management
                    </a>
                  </li>
                  <li className="nav-item">
                    <a href="#" className="nav-link">
                      E-Commerce
                    </a>
                  </li>
                </ul>
              </Collapse>
            </li>
            <li className="nav-item">
              <a
                className="nav-link"
                href="#"
                role="button"
                aria-expanded={openCategory === 'pages'}
                aria-controls="sidebarPages"
                onClick={(e) => handleCategoryClick(e, 'pages')}
              >
                <i className="fe fe-file"></i> Pages
              </a>
              <Collapse id="sidebarPages" isOpen={openCategory === 'pages'}>
                <ul className="nav nav-sm flex-column">
                  <li className="nav-item">
                    <a
                      href="#"
                      className="nav-link"
                      role="button"
                      aria-expanded={openSubcategory === 'account'}
                      aria-controls="sidebarAccount"
                      onClick={(e) => handleSubcategoryClick(e, 'account')}
                    >
                      Account
                    </a>
                    <Collapse
                      id="sidebarAccount"
                      isOpen={openSubcategory === 'account'}
                    >
                      <ul className="nav nav-sm flex-column">
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            General
                          </a>
                        </li>
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Billing
                          </a>
                        </li>
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Members
                          </a>
                        </li>
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Security
                          </a>
                        </li>
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Notifications
                          </a>
                        </li>
                      </ul>
                    </Collapse>
                  </li>
                  <li className="nav-item">
                    <a
                      href="#"
                      className="nav-link"
                      role="button"
                      aria-expanded={openSubcategory === 'crm'}
                      aria-controls="sidebarCrm"
                      onClick={(e) => handleSubcategoryClick(e, 'crm')}
                    >
                      CRM
                    </a>
                    <Collapse
                      id="sidebarCrm"
                      isOpen={openSubcategory === 'crm'}
                    >
                      <ul className="nav nav-sm flex-column">
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Contacts
                          </a>
                        </li>
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Companies
                          </a>
                        </li>
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Deals
                          </a>
                        </li>
                      </ul>
                    </Collapse>
                  </li>
                  <li className="nav-item">
                    <a
                      href="#"
                      className="nav-link"
                      role="button"
                      aria-expanded={openSubcategory === 'profile'}
                      aria-controls="sidebarProfile"
                      onClick={(e) => handleSubcategoryClick(e, 'profile')}
                    >
                      Profile
                    </a>
                    <Collapse
                      id="sidebarProfile"
                      isOpen={openSubcategory === 'profile'}
                    >
                      <ul className="nav nav-sm flex-column">
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Posts
                          </a>
                        </li>
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Groups
                          </a>
                        </li>
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Projects
                          </a>
                        </li>
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Files
                          </a>
                        </li>
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Subscribers
                          </a>
                        </li>
                      </ul>
                    </Collapse>
                  </li>
                  <li className="nav-item">
                    <a
                      href="#"
                      className="nav-link"
                      role="button"
                      aria-expanded={openSubcategory === 'project'}
                      aria-controls="sidebarProject"
                      onClick={(e) => handleSubcategoryClick(e, 'project')}
                    >
                      Project
                    </a>
                    <Collapse
                      id="sidebarProject"
                      isOpen={openSubcategory === 'project'}
                    >
                      <ul className="nav nav-sm flex-column">
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Overview
                          </a>
                        </li>
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Files
                          </a>
                        </li>
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Reports
                          </a>
                        </li>
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            New project
                          </a>
                        </li>
                      </ul>
                    </Collapse>
                  </li>
                  <li className="nav-item">
                    <a
                      href="#"
                      className="nav-link"
                      role="button"
                      aria-expanded={openSubcategory === 'team'}
                      aria-controls="sidebarTeam"
                      onClick={(e) => handleSubcategoryClick(e, 'team')}
                    >
                      Team
                    </a>
                    <Collapse
                      id="sidebarTeam"
                      isOpen={openSubcategory === 'team'}
                    >
                      <ul className="nav nav-sm flex-column">
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Overview
                          </a>
                        </li>
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Projects
                          </a>
                        </li>
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Members
                          </a>
                        </li>
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            New team
                          </a>
                        </li>
                      </ul>
                    </Collapse>
                  </li>
                  <li className="nav-item">
                    <a
                      href="#"
                      className="nav-link"
                      role="button"
                      aria-expanded={openSubcategory === 'feed'}
                      aria-controls="sidebarFeed"
                      onClick={(e) => handleSubcategoryClick(e, 'feed')}
                    >
                      Feed
                    </a>
                    <Collapse
                      id="sidebarFeed"
                      isOpen={openSubcategory === 'feed'}
                    >
                      <ul className="nav nav-sm flex-column">
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Platform
                          </a>
                        </li>
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Social
                          </a>
                        </li>
                      </ul>
                    </Collapse>
                  </li>
                  <li className="nav-item">
                    <a href="#" className="nav-link">
                      Wizard
                    </a>
                  </li>
                  <li className="nav-item">
                    <a href="#" className="nav-link">
                      Kanban
                    </a>
                  </li>
                  <li className="nav-item">
                    <a href="#" className="nav-link">
                      Orders
                    </a>
                  </li>
                  <li className="nav-item">
                    <a href="#" className="nav-link">
                      Invoice
                    </a>
                  </li>
                  <li className="nav-item">
                    <a href="#" className="nav-link">
                      Pricing
                    </a>
                  </li>
                </ul>
              </Collapse>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">
                <i className="fe fe-grid"></i> Widgets
              </a>
            </li>
            <li className="nav-item">
              <a
                className="nav-link"
                href="#"
                role="button"
                aria-expanded={openCategory === 'authentication'}
                aria-controls="sidebarAuth"
                onClick={(e) => handleCategoryClick(e, 'authentication')}
              >
                <i className="fe fe-user"></i> Authentication
              </a>
              <Collapse
                id="sidebarAuth"
                isOpen={openCategory === 'authentication'}
              >
                <ul className="nav nav-sm flex-column">
                  <li className="nav-item">
                    <a
                      href="#"
                      className="nav-link"
                      role="button"
                      aria-expanded={openSubcategory === 'signIn'}
                      aria-controls="sidebarSignIn"
                      onClick={(e) => handleSubcategoryClick(e, 'signIn')}
                    >
                      Sign in
                    </a>
                    <Collapse
                      id="sidebarSignIn"
                      isOpen={openSubcategory === 'signIn'}
                    >
                      <ul className="nav nav-sm flex-column">
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Cover
                          </a>
                        </li>
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Illustration
                          </a>
                        </li>
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Basic
                          </a>
                        </li>
                      </ul>
                    </Collapse>
                  </li>
                  <li className="nav-item">
                    <a
                      href="#"
                      className="nav-link"
                      role="button"
                      aria-expanded={openSubcategory === 'signUp'}
                      aria-controls="sidebarSignUp"
                      onClick={(e) => handleSubcategoryClick(e, 'signUp')}
                    >
                      Sign up
                    </a>
                    <Collapse
                      id="sidebarSignUp"
                      isOpen={openSubcategory === 'signUp'}
                    >
                      <ul className="nav nav-sm flex-column">
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Cover
                          </a>
                        </li>
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Illustration
                          </a>
                        </li>
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Basic
                          </a>
                        </li>
                      </ul>
                    </Collapse>
                  </li>
                  <li className="nav-item">
                    <a
                      href="#"
                      className="nav-link"
                      role="button"
                      aria-expanded={openSubcategory === 'passwordReset'}
                      aria-controls="sidebarPassword"
                      onClick={(e) =>
                        handleSubcategoryClick(e, 'passwordReset')
                      }
                    >
                      Password reset
                    </a>
                    <Collapse
                      id="sidebarPassword"
                      isOpen={openSubcategory === 'passwordReset'}
                    >
                      <ul className="nav nav-sm flex-column">
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Cover
                          </a>
                        </li>
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Illustration
                          </a>
                        </li>
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Basic
                          </a>
                        </li>
                      </ul>
                    </Collapse>
                  </li>
                  <li className="nav-item">
                    <a
                      href="#"
                      className="nav-link"
                      role="button"
                      aria-expanded={openSubcategory === 'error'}
                      aria-controls="sidebarError"
                      onClick={(e) => handleSubcategoryClick(e, 'error')}
                    >
                      Error
                    </a>
                    <Collapse
                      id="sidebarError"
                      isOpen={openSubcategory === 'error'}
                    >
                      <ul className="nav nav-sm flex-column">
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Illustration
                          </a>
                        </li>
                        <li className="nav-item">
                          <a href="#" className="nav-link">
                            Basic
                          </a>
                        </li>
                      </ul>
                    </Collapse>
                  </li>
                </ul>
              </Collapse>
            </li>
            <li className="nav-item d-md-none">
              <a className="nav-link" href="#">
                <span className="fe fe-bell"></span> Notifications
              </a>
            </li>
          </ul>

          {/* Navbar divider */}
          <hr className="navbar-divider my-3" />

          {/* Navbar heading */}
          <h6 className="navbar-heading">Documentation</h6>

          {/* Navbar nav */}
          <ul className="navbar-nav mb-md-4">
            <li className="nav-item">
              <a
                className="nav-link"
                href="#"
                role="button"
                aria-expanded={openCategory === 'basics'}
                aria-controls="sidebarBasics"
                onClick={(e) => handleCategoryClick(e, 'basics')}
              >
                <i className="fe fe-clipboard"></i> Basics
              </a>
              <Collapse id="sidebarBasics" isOpen={openCategory === 'basics'}>
                <ul className="nav nav-sm flex-column">
                  <li className="nav-item">
                    <a href="#" className="nav-link">
                      Getting Started
                    </a>
                  </li>
                  <li className="nav-item">
                    <a href="#" className="nav-link">
                      Design File
                    </a>
                  </li>
                </ul>
              </Collapse>
            </li>
            <li className="nav-item">
              <a
                className="nav-link"
                href="#"
                role="button"
                aria-expanded={openCategory === 'components'}
                aria-controls="sidebarComponents"
                onClick={(e) => handleCategoryClick(e, 'components')}
              >
                <i className="fe fe-book-open"></i> Components
              </a>
              <Collapse
                id="sidebarComponents"
                isOpen={openCategory === 'components'}
              >
                <ul className="nav nav-sm flex-column">
                  <li>
                    <a href="#" className="nav-link">
                      Alerts
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Autosize
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Avatars
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Badges
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Breadcrumb
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Buttons
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Button group
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Cards
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Charts
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Checklist
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Dropdowns
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Forms
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Icons
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Kanban
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Lists
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Map
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Modal
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Navs
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Navbar
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Page headers
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Pagination
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Popovers
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Progress
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Social post
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Spinners
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Tables
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Toasts
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Tooltips
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Typography
                    </a>
                  </li>
                  <li>
                    <a href="#" className="nav-link">
                      Utilities
                    </a>
                  </li>
                </ul>
              </Collapse>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">
                <i className="fe fe-git-branch"></i> Changelog
              </a>
            </li>
          </ul>

          {/* Spacer */}
          <div className="mt-auto"></div>

          {/* Navbar user */}
          <div className="navbar-user d-none d-md-flex" id="sidebarUser">
            <a className="navbar-user-link" href="#">
              <span className="icon">
                <i className="fe fe-bell"></i>
              </span>
            </a>
            <div className="dropup">
              <a
                href="#"
                id="sidebarIconCopy"
                className="dropdown-toggle"
                role="button"
                aria-haspopup="true"
                aria-expanded={!!openDropdown}
                onClick={(e) => handleDropdownClick(e, !openDropdown)}
              >
                <div className="avatar avatar-sm avatar-online">
                  <img
                    src="/img/avatars/profiles/avatar-1.jpg"
                    className="avatar-img rounded-circle"
                    alt="..."
                  />
                </div>
              </a>
              <div
                className={`dropdown-menu ${openDropdown && 'show'}`}
                aria-labelledby="sidebarIconCopy"
              >
                <a href="#" className="dropdown-item">
                  Profile
                </a>
                <a href="#" className="dropdown-item">
                  Settings
                </a>
                <hr className="dropdown-divider" />
                <a href="#" className="dropdown-item">
                  Logout
                </a>
              </div>
            </div>
            <a href="#" className="navbar-user-link">
              <span className="icon">
                <i className="fe fe-search"></i>
              </span>
            </a>
          </div>
        </Collapse>
      </div>
    </nav>
  );
}
