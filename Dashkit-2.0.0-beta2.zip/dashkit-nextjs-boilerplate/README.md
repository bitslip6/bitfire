# Dashkit Next.js Boilerplate

This is a Dashkit [Next.js](https://nextjs.org/) boilerplate project bootstrapped with [`create-next-app`](https://github.com/vercel/next.js/tree/canary/packages/create-next-app). 

The goals of this project are to demonstrate the right way to:
- Include and extend Dashkit's SCSS files within a React application.
- Convert Dashkit markup into React components.
- Replace vanilla JS dependencies with React alternatives (i.e. Bootstrap's "Collapse" plugin replaced by `react-css-collapse`).

A couple other notes:
- This build includes Dashkit v2 which is based on Bootstrap 5.
- In the future, it will be possible to use popular solutions like [https://react-bootstrap.github.io/](https://react-bootstrap.github.io/) once those libraries are updated to Bootstrap v5.

### Getting Started

- npm install
- npm run dev
- Open [http://localhost:3000](http://localhost:3000)

### Documentation

- Next.js documentation is available at [`https://nextjs.org/docs`](https://nextjs.org/docs).
- Dashkit documentation is available at [`https://dashkit.goodthemes.co/v/2.0.0-beta2/docs/getting-started.html`](https://dashkit.goodthemes.co/v/2.0.0-beta2/docs/getting-started.html).

### Support

Good Themes is happy to provide support for issues. Shoot us an email at support@goodthemes.co and we'll get you squared away.
