export default function Home() {
  return (
    <>
      <h1>Pages#index</h1>
      <p>Find me in pages/index.js</p>
    </>
  );
}
