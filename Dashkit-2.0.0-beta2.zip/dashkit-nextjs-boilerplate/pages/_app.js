import '../styles/theme.scss';

import Head from 'next/head';

import { Sidenav } from '../components';

function MyApp({ Component, pageProps }) {
  return (
    <>
      <Head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon/favicon.ico" />
        <title>Dashkit</title>
      </Head>
      <Sidenav />
      <div className="main-content">
        <Component {...pageProps} />
      </div>
    </>
  );
}

export default MyApp;
